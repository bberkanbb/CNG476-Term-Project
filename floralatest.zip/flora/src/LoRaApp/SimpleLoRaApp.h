#ifndef __LORA_OMNET_SIMPLELORAAPP_H_
#define __LORA_OMNET_SIMPLELORAAPP_H_

#include <omnetpp.h>
#include "inet/common/lifecycle/ILifecycle.h"
#include "inet/common/lifecycle/NodeStatus.h"
#include "inet/common/ModuleAccess.h"
#include "inet/common/lifecycle/LifecycleOperation.h"

#include "LoRaAppPacket_m.h"
#include "LoRa/LoRaMacControlInfo_m.h"
#include "LoRa/LoRaRadio.h"

using namespace omnetpp;
using namespace inet;

namespace flora {

class SimpleLoRaApp : public cSimpleModule, public ILifecycle
{
  protected:
    // Core OMNeT++ methods
    void initialize(int stage) override;
    void finish() override;
    int numInitStages() const override { return NUM_INIT_STAGES; }
    void handleMessage(cMessage *msg) override;
    virtual bool handleOperationStage(LifecycleOperation *operation, IDoneCallback *doneCallback) override;

    // Packet and protocol methods
    void handleMessageFromLowerLayer(cMessage *msg);
    std::pair<double,double> generateUniformCircleCoordinates(double radius, double gatewayX, double gatewayY);
    void sendJoinRequest();

    // Packet tracking
    int numberOfPacketsToSend;
    int sentPackets;
    int receivedADRCommands;
    int lastSentMeasurement;

    // Trash fill logic
    int fillLevel = 0;
    int threshold;
    simtime_t reportInterval;

    // Events
    cMessage *selfEvent = nullptr;
    cMessage *resetFillEvent = nullptr;

    // ADR/LoRa
    simtime_t timeToFirstPacket;
    simtime_t timeToNextPacket;
    LoRaRadio *loRaRadio;

    cOutVector sfVector;
    cOutVector tpVector;

    // ADR control
    bool evaluateADRinNode;
    int ADR_ACK_CNT = 0;
    int ADR_ACK_LIMIT = 64;
    int ADR_ACK_DELAY = 32;
    bool sendNextPacketWithADRACKReq = false;
    void increaseSFIfPossible();

    // Accessors
    void setSF(int SF);
    int getSF();
    void setTP(int TP);
    double getTP();
    void setCR(int CR);
    int getCR();
    void setCF(units::values::Hz CF);
    units::values::Hz getCF();
    void setBW(units::values::Hz BW);
    units::values::Hz getBW();

  public:
    SimpleLoRaApp() {}
    simsignal_t LoRa_AppPacketSent;
};

} // namespace flora

#endif
