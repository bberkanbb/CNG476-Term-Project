#include "SimpleLoRaApp.h"
#include "inet/mobility/static/StationaryMobility.h"
#include "../LoRa/LoRaTagInfo_m.h"
#include "inet/common/packet/Packet.h"

namespace flora {

Define_Module(SimpleLoRaApp);

void SimpleLoRaApp::initialize(int stage)
{
    cSimpleModule::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {
        threshold = 80; // Configurable
        reportInterval = 60;
        fillLevel = 0;

        selfEvent = new cMessage("selfEvent");
        resetFillEvent = new cMessage("resetFillEvent");

        // Start checking trash level
        scheduleAt(simTime() + reportInterval, selfEvent);

        std::pair<double,double> coordsValues = std::make_pair(-1, -1);
        cModule *host = getContainingNode(this);
        if (strcmp(host->par("deploymentType").stringValue(), "circle") == 0) {
            coordsValues = generateUniformCircleCoordinates(
                host->par("maxGatewayDistance").doubleValue(),
                host->par("gatewayX").doubleValue(),
                host->par("gatewayY").doubleValue());

            StationaryMobility *mobility = check_and_cast<StationaryMobility *>(host->getSubmodule("mobility"));
            mobility->par("initialX").setDoubleValue(coordsValues.first);
            mobility->par("initialY").setDoubleValue(coordsValues.second);
        }
    }
    else if (stage == INITSTAGE_APPLICATION_LAYER) {
        NodeStatus *nodeStatus = dynamic_cast<NodeStatus *>(findContainingNode(this)->getSubmodule("status"));
        bool isOperational = (!nodeStatus) || nodeStatus->getState() == NodeStatus::UP;
        if (!isOperational)
            throw cRuntimeError("This module doesn't support starting in node DOWN state");

        do {
            timeToFirstPacket = par("timeToFirstPacket");
            EV << "Wylosowalem czas :" << timeToFirstPacket << endl;
        } while (timeToFirstPacket <= 5);

        sentPackets = 0;
        receivedADRCommands = 0;
        numberOfPacketsToSend = par("numberOfPacketsToSend");

        LoRa_AppPacketSent = registerSignal("LoRa_AppPacketSent");

        loRaRadio = check_and_cast<LoRaRadio *>(getParentModule()->getSubmodule("LoRaNic")->getSubmodule("radio"));
        loRaRadio->loRaTP = par("initialLoRaTP").doubleValue();
        loRaRadio->loRaCF = units::values::Hz(par("initialLoRaCF").doubleValue());
        loRaRadio->loRaSF = par("initialLoRaSF");
        loRaRadio->loRaBW = inet::units::values::Hz(par("initialLoRaBW").doubleValue());
        loRaRadio->loRaCR = par("initialLoRaCR");
        loRaRadio->loRaUseHeader = par("initialUseHeader");
        evaluateADRinNode = par("evaluateADRinNode");
        sfVector.setName("SF Vector");
        tpVector.setName("TP Vector");
    }
}

std::pair<double,double> SimpleLoRaApp::generateUniformCircleCoordinates(double radius, double gatewayX, double gatewayY)
{
    double randomValueRadius = uniform(0, (radius * radius));
    double randomTheta = uniform(0, 2 * M_PI);
    double x = sqrt(randomValueRadius) * cos(randomTheta);
    double y = sqrt(randomValueRadius) * sin(randomTheta);
    x = x + gatewayX;
    y = gatewayY - y;
    return std::make_pair(x, y);
}

void SimpleLoRaApp::finish()
{
    cModule *host = getContainingNode(this);
    StationaryMobility *mobility = check_and_cast<StationaryMobility *>(host->getSubmodule("mobility"));
    Coord coord = mobility->getCurrentPosition();
    recordScalar("positionX", coord.x);
    recordScalar("positionY", coord.y);
    recordScalar("finalTP", getTP());
    recordScalar("finalSF", getSF());
    recordScalar("sentPackets", sentPackets);
    recordScalar("receivedADRCommands", receivedADRCommands);
    cancelAndDelete(selfEvent);
    cancelAndDelete(resetFillEvent);
}

void SimpleLoRaApp::handleMessage(cMessage *msg)
{
    if (msg == selfEvent) {
        int added = intuniform(5, 15);
        fillLevel = std::min(100, fillLevel + added);
        EV << "Trash fill increased to: " << fillLevel << "%\n";

        if (fillLevel >= threshold) {
            EV << "Threshold exceeded. Sending message to gateway.\n";
            sendJoinRequest();

            if (resetFillEvent->isScheduled())
                cancelEvent(resetFillEvent);
            simtime_t resetDelay = uniform(10, 30);
            scheduleAt(simTime() + resetDelay, resetFillEvent);
        }

        scheduleAt(simTime() + reportInterval, selfEvent);
        return;
    }

    if (msg == resetFillEvent) {
        EV << "Trash bin emptied. Fill level reset to 0%.\n";
        fillLevel = 0;
        return;
    }

    if (!msg->isSelfMessage()) {
        handleMessageFromLowerLayer(msg);
        delete msg;
    }
}

void SimpleLoRaApp::sendJoinRequest()
{
    if (fillLevel < threshold) {
        EV << "Bin not full enough (" << fillLevel << "%), not sending packet.\n";
        return;
    }

    EV << "Bin full (" << fillLevel << "%), sending packet.\n";

    auto pktRequest = new Packet("DataFrame");
    pktRequest->setKind(DATA);

    auto payload = makeShared<LoRaAppPacket>();
    payload->setChunkLength(B(par("dataSize").intValue()));
    lastSentMeasurement = fillLevel;
    payload->setSampleMeasurement(fillLevel);

    if (evaluateADRinNode && sendNextPacketWithADRACKReq) {
        auto opt = payload->getOptions();
        opt.setADRACKReq(true);
        payload->setOptions(opt);
        sendNextPacketWithADRACKReq = false;
    }

    auto loraTag = pktRequest->addTagIfAbsent<LoRaTag>();
    loraTag->setBandwidth(getBW());
    loraTag->setCenterFrequency(getCF());
    loraTag->setSpreadFactor(getSF());
    loraTag->setCodeRendundance(getCR());
    loraTag->setPower(mW(math::dBmW2mW(getTP())));

    sfVector.record(getSF());
    tpVector.record(getTP());
    pktRequest->insertAtBack(payload);
    send(pktRequest, "socketOut");

    if (evaluateADRinNode) {
        ADR_ACK_CNT++;
        if (ADR_ACK_CNT == ADR_ACK_LIMIT) sendNextPacketWithADRACKReq = true;
        if (ADR_ACK_CNT >= ADR_ACK_LIMIT + ADR_ACK_DELAY) {
            ADR_ACK_CNT = 0;
            increaseSFIfPossible();
        }
    }

    emit(LoRa_AppPacketSent, getSF());
}

void SimpleLoRaApp::handleMessageFromLowerLayer(cMessage *msg)
{
    auto pkt = check_and_cast<Packet *>(msg);
    const auto &packet = pkt->peekAtFront<LoRaAppPacket>();
    if (simTime() >= getSimulation()->getWarmupPeriod())
        receivedADRCommands++;
    if (evaluateADRinNode && packet->getMsgType() == TXCONFIG) {
        if (packet->getOptions().getLoRaTP() != -1) setTP(packet->getOptions().getLoRaTP());
        if (packet->getOptions().getLoRaSF() != -1) setSF(packet->getOptions().getLoRaSF());
        EV << "New TP " << getTP() << endl;
        EV << "New SF " << getSF() << endl;
    }
}

bool SimpleLoRaApp::handleOperationStage(LifecycleOperation *operation, IDoneCallback *doneCallback)
{
    Enter_Method_Silent();
    throw cRuntimeError("Unsupported lifecycle operation '%s'", operation->getClassName());
    return true;
}

void SimpleLoRaApp::increaseSFIfPossible() {
    if (getSF() < 12) setSF(getSF() + 1);
}

void SimpleLoRaApp::setSF(int SF) { loRaRadio->loRaSF = SF; }
int SimpleLoRaApp::getSF() { return loRaRadio->loRaSF; }
void SimpleLoRaApp::setTP(int TP) { loRaRadio->loRaTP = TP; }
double SimpleLoRaApp::getTP() { return loRaRadio->loRaTP; }
void SimpleLoRaApp::setCF(units::values::Hz CF) { loRaRadio->loRaCF = CF; }
units::values::Hz SimpleLoRaApp::getCF() { return loRaRadio->loRaCF; }
void SimpleLoRaApp::setBW(units::values::Hz BW) { loRaRadio->loRaBW = BW; }
units::values::Hz SimpleLoRaApp::getBW() { return loRaRadio->loRaBW; }
void SimpleLoRaApp::setCR(int CR) { loRaRadio->loRaCR = CR; }
int SimpleLoRaApp::getCR() { return loRaRadio->loRaCR; }

} // namespace flora
